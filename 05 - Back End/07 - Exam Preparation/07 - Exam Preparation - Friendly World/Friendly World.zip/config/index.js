module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: 'mongodb://0.0.0.0:27017/friendly-world',
    COOKIE_NAME: 'SESSION_TOKEN',
    TOKEN_SECRET: 'abso-fucking-lutely_secret'
};