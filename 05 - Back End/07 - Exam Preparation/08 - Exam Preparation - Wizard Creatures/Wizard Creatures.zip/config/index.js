module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: 'mongodb+srv://DBeneva:1qaz%40WSX@cluster0.asdxapn.mongodb.net/wizard-creatures',
    COOKIE_NAME: 'SESSION_TOKEN',
    TOKEN_SECRET: 'abso-fucking-lutely_secret'
};